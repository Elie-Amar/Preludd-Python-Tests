# Preludd-tests

![alt text](https://github.com/iMBSoD/Preludd-tests/blob/master/timings.PNG)
