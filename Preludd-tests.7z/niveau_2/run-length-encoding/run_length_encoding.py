def decode(string):
    pass


def encode(string):
    pass
