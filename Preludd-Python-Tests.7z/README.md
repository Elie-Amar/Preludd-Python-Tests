# Preludd-tests

![alt text](https://github.com/iMBSoD/Preludd-Python-Tests/blob/main/timings.PNG)
