def append(xs, ys):
    pass


def concat(lists):
    pass


def filter_clone(function, xs):
    pass


def length(xs):
    pass


def map_clone(function, xs):
    pass


def foldl(function, xs, acc):
    pass


def foldr(function, xs, acc):
    pass


def reverse(xs):
    pass
